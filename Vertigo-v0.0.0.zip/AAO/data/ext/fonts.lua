SMODS.Font{
    key = "Vazir",
    path = "ext\fonts/Vazir.ttf",
    render_scale = 140,
    TEXT_HEIGHT_SCALE = 0.65, 
    TEXT_OFFSET = {x=0,y=0}, 
    FONTSCALE = 0.12,
    squish = 1, 
    DESCSCALE = 1
}