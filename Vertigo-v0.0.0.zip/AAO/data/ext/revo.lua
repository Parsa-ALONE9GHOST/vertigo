-- hiker p --
SMODS.Joker({
	key = "hikinter",
	atlas = "hikr",
	rarity = "crv_p",
	cost = 10,
	unlocked = true,
	discovered = false,
	blueprint_compat = false,
	
	pos = {
		x = 0,
		y = 0,
	},
	config = {
		extra = {},
	},
	loc_txt = {
  		    name = "Hikinter",
			text = {
				"When Blind is selected,",
				"print a {C:attention}Hiker{} Joker",
			}
		},
	dependencies = "RevosVault",
	loc_vars = function(self, info_queue, center)
		info_queue[#info_queue + 1] = G.P_CENTERS.j_hiker
	end,
	calculate = function(self, card, context)
		if context.setting_blind and not context.blueprint then
			if
				G.GAME.used_vouchers["v_crv_printerup"] == true
					and pseudorandom("ALLPRINTER") < G.GAME.probabilities.normal / 4
				or G.GAME.used_vouchers["v_crv_printeruptier"] == true
			then
				local new_card = create_card("Hiker", G.jokers, nil, nil, nil, nil, "j_hiker")
				new_card:add_to_deck()
				new_card:set_edition({ negative = true }, true)
				G.jokers:emplace(new_card)
			else
				if #G.jokers.cards < G.jokers.config.card_limit or self.area == G.jokers then
					local new_card = create_card("Hiker", G.jokers, nil, nil, nil, nil, "j_hiker")
					new_card:add_to_deck()
					G.jokers:emplace(new_card)
				end
			end
		end
	end,

	in_pool = function(self, wawa, wawa2)
		return true
	end,
})
-- dna p --
SMODS.Joker({
	key = "pna",
	atlas = "blood_tsta",
	rarity = "crv_p",
	cost = 10,
	unlocked = true,
	discovered = false,
	blueprint_compat = false,
	
	pos = {
		x = 0,
		y = 0,
	},
	config = {
		extra = {},
	},
	loc_txt = {
  		    name = "Blood Test Printer",
			text = {
				"When Blind is selected,",
				"print a {C:attention}DNA{} Joker",
			}
		},
	dependencies = "RevosVault",
	loc_vars = function(self, info_queue, center)
		info_queue[#info_queue + 1] = G.P_CENTERS.j_dna
	end,
	calculate = function(self, card, context)
		if context.setting_blind and not context.blueprint then
			if
				G.GAME.used_vouchers["v_crv_printerup"] == true
					and pseudorandom("ALLPRINTER") < G.GAME.probabilities.normal / 4
				or G.GAME.used_vouchers["v_crv_printeruptier"] == true
			then
				local new_card = create_card("DNA", G.jokers, nil, nil, nil, nil, "j_dna")
				new_card:add_to_deck()
				new_card:set_edition({ negative = true }, true)
				G.jokers:emplace(new_card)
			else
				if #G.jokers.cards < G.jokers.config.card_limit or self.area == G.jokers then
					local new_card = create_card("DNA", G.jokers, nil, nil, nil, nil, "j_dna")
					new_card:add_to_deck()
					G.jokers:emplace(new_card)
				end
			end
		end
	end,

	in_pool = function(self, wawa, wawa2)
		return true
	end,
})
-- joker p --
SMODS.Joker({
	key = "jokpr",
	atlas = "part__prin",
	rarity = "crv_p",
	cost = 10,
	unlocked = true,
	discovered = false,
	blueprint_compat = false,
	pos = {
		x = 0,
		y = 0,
	},
	config = {
		extra = {},
	},
	loc_txt = {
  		    name = "Cartridge Reader",
			text = {
				"When Blind is selected,",
				"prints 2 {C:edition}negative{} {C:attention}Joker{}",
			}
		},
	dependencies = "RevosVault",
	loc_vars = function(self, info_queue, center)
		info_queue[#info_queue + 1] = G.P_CENTERS.e_negative
	end,
	calculate = function(self, card, context)
		if context.setting_blind and not context.blueprint then
			if
				G.GAME.used_vouchers["v_crv_printerup"] == true
					and pseudorandom("ALLPRINTER") < G.GAME.probabilities.normal / 4
				or G.GAME.used_vouchers["v_crv_printeruptier"] == true
			then
				local new_card = create_card("Joker", G.jokers, nil, nil, nil, nil, "j_joker")
				new_card:add_to_deck()
				new_card:set_edition({ negative = true }, true)
				G.jokers:emplace(new_card)
				local new_card = create_card("Joker", G.jokers, nil, nil, nil, nil, "j_joker")
				new_card:add_to_deck()
				new_card:set_edition({ negative = true }, true)
				G.jokers:emplace(new_card)
			else
					local new_card = create_card("Joker", G.jokers, nil, nil, nil, nil, "j_joker")
					new_card:add_to_deck()
 					new_card:set_edition({ negative = true }, true)
					G.jokers:emplace(new_card)
					local new_card = create_card("Joker", G.jokers, nil, nil, nil, nil, "j_joker")
					new_card:add_to_deck()
					new_card:set_edition({ negative = true }, true)
					G.jokers:emplace(new_card)
			end
		end
	end,

	in_pool = function(self, wawa, wawa2)
		return true
	end,
})
-- seltzer p --
SMODS.Joker({
	key = "peltzer",
	atlas = "peltzeratl",
	rarity = "crv_p",
	cost = 10,
	unlocked = true,
	discovered = false,
	blueprint_compat = false,
	pos = {
		x = 0,
		y = 0,
	},
	config = {
		extra = {},
	},
	loc_txt = {
  		    name = "Seltzer Printer",
			text = {
				"When Blind is selected,",
				"print a {C:attention}Seltzer{} Joker",
			}
		},
	dependencies = "RevosVault",
	loc_vars = function(self, info_queue, center)
		info_queue[#info_queue + 1] = G.P_CENTERS.j_selzer
	end,
	calculate = function(self, card, context)
		if context.setting_blind and not context.blueprint then
			if
				G.GAME.used_vouchers["v_crv_printerup"] == true
					and pseudorandom("ALLPRINTER") < G.GAME.probabilities.normal / 4
				or G.GAME.used_vouchers["v_crv_printeruptier"] == true
			then
				local new_card = create_card("Seltzer", G.jokers, nil, nil, nil, nil, "j_selzer")
				new_card:add_to_deck()
				new_card:set_edition({ negative = true }, true)
				G.jokers:emplace(new_card)
			else
				if #G.jokers.cards < G.jokers.config.card_limit or self.area == G.jokers then
					local new_card = create_card("Seltzer", G.jokers, nil, nil, nil, nil, "j_selzer")
					new_card:add_to_deck()
					G.jokers:emplace(new_card)
				end
			end
		end
	end,

	in_pool = function(self, wawa, wawa2)
		return true
	end,
})
-- stencil p --
SMODS.Joker({
	key = "eetencil",
	atlas = "atlstencil",
	rarity = "crv_p",
	cost = 10,
	unlocked = true,
	discovered = false,
	blueprint_compat = false,
	pos = {
		x = 0,
		y = 0,
	},
	config = {
		extra = {},
	},
	loc_txt = {
  		    name = "Stencil Printer",
			text = {
				"When Blind is selected,",
				"print a {C:attention}Stencil{} Joker",
			}
		},
	dependencies = "RevosVault",
	loc_vars = function(self, info_queue, center)
		info_queue[#info_queue + 1] = G.P_CENTERS.j_stencil
	end,
	calculate = function(self, card, context)
		if context.setting_blind and not context.blueprint then
			if
				G.GAME.used_vouchers["v_crv_printerup"] == true
					and pseudorandom("ALLPRINTER") < G.GAME.probabilities.normal / 4
				or G.GAME.used_vouchers["v_crv_printeruptier"] == true
			then
				local new_card = create_card("Stencil", G.jokers, nil, nil, nil, nil, "j_stencil")
				new_card:add_to_deck()
				new_card:set_edition({ negative = true }, true)
				G.jokers:emplace(new_card)
			else
				if #G.jokers.cards < G.jokers.config.card_limit or self.area == G.jokers then
					local new_card = create_card("Stencil", G.jokers, nil, nil, nil, nil, "j_stencil")
					new_card:add_to_deck()
					G.jokers:emplace(new_card)
				end
			end
		end
	end,

	in_pool = function(self, wawa, wawa2)
		return true
	end,
})
-- egg p --
SMODS.Joker({
	key = "eggpp",
	atlas = "atlegg",
	rarity = "crv_p",
	cost = 10,
	unlocked = true,
	discovered = false,
	blueprint_compat = false,
	pos = {
		x = 0,
		y = 0,
	},
	config = {
		extra = {},
	},
	loc_txt = {
  		    name = "Egg Printer",
			text = {
				"When Blind is selected,",
				"print a {C:attention}Egg{} Joker",
			}
		},
	dependencies = "RevosVault",
	loc_vars = function(self, info_queue, center)
		info_queue[#info_queue + 1] = G.P_CENTERS.j_egg
	end,
	calculate = function(self, card, context)
		if context.setting_blind and not context.blueprint then
			if
				G.GAME.used_vouchers["v_crv_printerup"] == true
					and pseudorandom("ALLPRINTER") < G.GAME.probabilities.normal / 4
				or G.GAME.used_vouchers["v_crv_printeruptier"] == true
			then
				local new_card = create_card("Egg", G.jokers, nil, nil, nil, nil, "j_egg")
				new_card:add_to_deck()
				new_card:set_edition({ negative = true }, true)
				G.jokers:emplace(new_card)
			else
				if #G.jokers.cards < G.jokers.config.card_limit or self.area == G.jokers then
					local new_card = create_card("Egg", G.jokers, nil, nil, nil, nil, "j_egg")
					new_card:add_to_deck()
					G.jokers:emplace(new_card)
				end
			end
		end
	end,

	in_pool = function(self, wawa, wawa2)
		return true
	end,
})
-- todd p --
SMODS.Joker({
	key = "oddp",
	atlas = "atloddp",
	rarity = "crv_p",
	cost = 10,
	unlocked = true,
	discovered = false,
	blueprint_compat = false,
	pos = {
		x = 0,
		y = 0,
	},
	config = {
		extra = {},
	},
	loc_txt = {
  		    name = "Odd Todd Printer",
			text = {
				"When Blind is selected,",
				"print an {C:attention}Odd Todd{} Joker",
			}
		},
	dependencies = "RevosVault",
	loc_vars = function(self, info_queue, center)
		info_queue[#info_queue + 1] = G.P_CENTERS.j_odd_todd
	end,
	calculate = function(self, card, context)
		if context.setting_blind and not context.blueprint then
			if
				G.GAME.used_vouchers["v_crv_printerup"] == true
					and pseudorandom("ALLPRINTER") < G.GAME.probabilities.normal / 4
				or G.GAME.used_vouchers["v_crv_printeruptier"] == true
			then
				local new_card = create_card("Odd Todd", G.jokers, nil, nil, nil, nil, "j_odd_todd")
				new_card:add_to_deck()
				new_card:set_edition({ negative = true }, true)
				G.jokers:emplace(new_card)
			else
				if #G.jokers.cards < G.jokers.config.card_limit or self.area == G.jokers then
					local new_card = create_card("Odd Todd", G.jokers, nil, nil, nil, nil, "j_odd_todd")
					new_card:add_to_deck()
					G.jokers:emplace(new_card)
				end
			end
		end
	end,

	in_pool = function(self, wawa, wawa2)
		return true
	end,
})
-- even p --
SMODS.Joker({
	key = "evenpr",
	atlas = "atleven",
	rarity = "crv_p",
	cost = 10,
	unlocked = true,
	discovered = false,
	blueprint_compat = false,
	pos = {
		x = 0,
		y = 0,
	},
	config = {
		extra = {},
	},
	loc_txt = {
  		    name = "Even Steven Printer",
			text = {
				"When Blind is selected,",
				"print an {C:attention}Even Steven{} Joker",
			}
		},
	dependencies = "RevosVault",
	loc_vars = function(self, info_queue, center)
		info_queue[#info_queue + 1] = G.P_CENTERS.j_even_steven
	end,
	calculate = function(self, card, context)
		if context.setting_blind and not context.blueprint then
			if
				G.GAME.used_vouchers["v_crv_printerup"] == true
					and pseudorandom("ALLPRINTER") < G.GAME.probabilities.normal / 4
				or G.GAME.used_vouchers["v_crv_printeruptier"] == true
			then
				local new_card = create_card("Even Steven", G.jokers, nil, nil, nil, nil, "j_even_steven")
				new_card:add_to_deck()
				new_card:set_edition({ negative = true }, true)
				G.jokers:emplace(new_card)
			else
				if #G.jokers.cards < G.jokers.config.card_limit or self.area == G.jokers then
					local new_card = create_card("Even Steven", G.jokers, nil, nil, nil, nil, "j_even_steven")
					new_card:add_to_deck()
					G.jokers:emplace(new_card)
				end
			end
		end
	end,

	in_pool = function(self, wawa, wawa2)
		return true
	end,
})
-- golden p --
SMODS.Joker({
	key = "goldenp",
	atlas = "atlgold",
	rarity = "crv_p",
	cost = 10,
	unlocked = true,
	discovered = false,
	blueprint_compat = false,
	pos = {
		x = 0,
		y = 0,
	},
	config = {
		extra = {},
	},
	loc_txt = {
  		    name = "Golden Printer",
			text = {
				"When Blind is selected,",
				"print a {C:attention}Golden Joker{}",
			}
		},
	dependencies = "RevosVault",
	loc_vars = function(self, info_queue, center)
		info_queue[#info_queue + 1] = G.P_CENTERS.j_golden
	end,
	calculate = function(self, card, context)
		if context.setting_blind and not context.blueprint then
			if
				G.GAME.used_vouchers["v_crv_printerup"] == true
					and pseudorandom("ALLPRINTER") < G.GAME.probabilities.normal / 4
				or G.GAME.used_vouchers["v_crv_printeruptier"] == true
			then
				local new_card = create_card("Golden", G.jokers, nil, nil, nil, nil, "j_golden")
				new_card:add_to_deck()
				new_card:set_edition({ negative = true }, true)
				G.jokers:emplace(new_card)
			else
				if #G.jokers.cards < G.jokers.config.card_limit or self.area == G.jokers then
					local new_card = create_card("Golden", G.jokers, nil, nil, nil, nil, "j_golden")
					new_card:add_to_deck()
					G.jokers:emplace(new_card)
				end
			end
		end
	end,

	in_pool = function(self, wawa, wawa2)
		return true
	end,
})
-- space p --
SMODS.Joker({
	key = "spacep",
	atlas = "atlspc",
	rarity = "crv_p",
	cost = 10,
	unlocked = true,
	discovered = false,
	blueprint_compat = false,
	pos = {
		x = 0,
		y = 0,
	},
	config = {
		extra = {},
	},
	loc_txt = {
  		    name = "Space Printer",
			text = {
				"When Blind is selected,",
				"print a {C:attention}Space Joker{}",
			}
		},
	dependencies = "RevosVault",
	loc_vars = function(self, info_queue, center)
		info_queue[#info_queue + 1] = G.P_CENTERS.j_space
	end,
	calculate = function(self, card, context)
		if context.setting_blind and not context.blueprint then
			if
				G.GAME.used_vouchers["v_crv_printerup"] == true
					and pseudorandom("ALLPRINTER") < G.GAME.probabilities.normal / 4
				or G.GAME.used_vouchers["v_crv_printeruptier"] == true
			then
				local new_card = create_card("Space", G.jokers, nil, nil, nil, nil, "j_space")
				new_card:add_to_deck()
				new_card:set_edition({ negative = true }, true)
				G.jokers:emplace(new_card)
			else
				if #G.jokers.cards < G.jokers.config.card_limit or self.area == G.jokers then
					local new_card = create_card("Space", G.jokers, nil, nil, nil, nil, "j_space")
					new_card:add_to_deck()
					G.jokers:emplace(new_card)
				end
			end
		end
	end,

	in_pool = function(self, wawa, wawa2)
		return true
	end,
})
