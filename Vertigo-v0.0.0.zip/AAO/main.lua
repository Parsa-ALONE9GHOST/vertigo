Palatro = SMODS.current_mod
Palatro.compat = {
	buffoonery = (SMODS.Mods['Buffoonery'] or {}).can_load,
	unstable = (SMODS.Mods['UnStable'] or {}).can_load,
	ortalab = (SMODS.Mods['Ortalab'] or {}).can_load,
    familiar = (SMODS.Mods['familiar'] or {}).can_load,
    toga = (SMODS.Mods["TOGAPack"] or {}).can_load,
    maximus = (SMODS.Mods["Maximus"] or {}).can_load,
    aiko = (SMODS.Mods["aikoyorisshenanigans"] or {}).can_load,
    funk = (SMODS.Mods["celestial_funk_limeeffy"] or {}).can_load,
}
G.C.COUN = {5/255, 105/255, 45/255, 1}
SMODS.ConsumableType{
    key = 'randmcrd',
    collection_rows = {4,5},
    name = 'Country',
    loc_txt = {
        name = 'Country Cards',
        collection = 'Country Cards',
    },
    primary_colour = G.C.WHITE,
    secondary_colour = G.C.COUN,
    shop_rate = 0.9,
    pack_weights = {
        common = 1,
        rare = 0.5
    },
}
G.C.RANDOOM = {201/255, 0/255, 101/255, 1}
SMODS.ConsumableType{
    key = '?????',
    collection_rows = {2,3},
    name = '???',
    loc_txt = {
        name = '??? Cards',
        collection = '??? Cards',
    },
    primary_colour = G.C.WHITE,
    secondary_colour = G.C.RANDOOM,
    shop_rate = 0,
    pack_weights = {
        common = 0.5,
        rare = 0.25
    },
}
--load
NFS.load(Palatro.path .. 'data/pal/Atlas/Atlas.lua')()
NFS.load(Palatro.path .. 'data/pal/Enhance/Mint.lua')()
NFS.load(Palatro.path .. 'data/pal/Joker/Rohamsi.lua')()
NFS.load(Palatro.path .. 'data/pal/Joker/Title.lua')()
NFS.load(Palatro.path .. 'data/pal/Joker/green_tree.lua')()
NFS.load(Palatro.path .. 'data/pal/cons/Mintation.lua')()
NFS.load(Palatro.path .. 'data/pal/cons/see.lua')()
NFS.load(Palatro.path .. 'data/pal/cons/hcon.lua')()
-- NFS.load(Palatro.path .. 'data/cons/countries.lua')()
NFS.load(Palatro.path .. 'data/pal/Enhance/countries.lua')()
NFS.load(Palatro.path .. 'data/pal/Joker/art.lua')()
NFS.load(Palatro.path .. 'data/pal/Joker/ace.lua')()
NFS.load(Palatro.path .. 'data/pal/Joker/parsi.lua')()
NFS.load(Palatro.path .. 'data/pal/Joker/poker_face.lua')()
NFS.load(Palatro.path .. 'data/pal/Joker/walker.lua')()
NFS.load(Palatro.path .. 'data/pal/Joker/Parsa.lua')()
--dorkshire tea for hard water (only when buffoonery mod is active)
		if Palatro.compat.buffoonery then
             NFS.load(Palatro.path .. 'data/pal/Joker/dorkshire_h.lua')()
             NFS.load(Palatro.path .. 'data/pal/Enhance/Porcelain.lua')()
             NFS.load(Palatro.path .. 'data/ons/blind.lua')()
		end
        NFS.load(Palatro.path .. 'data/pal/Joker/swap_tree.lua')()
        SMODS.Sound({
            key = 'ring',
        path = 'pal/Ring.ogg'
        })
        SMODS.Sound({
            key = 'randmusic',
        path = 'Rand.ogg',
	select_music_track = function() --unstable
		return ( G.pack_cards and G.pack_cards.cards and G.pack_cards.cards[1] and G.pack_cards.cards[1].ability.set == "?????") or ( G.pack_cards and G.pack_cards.cards and G.pack_cards.cards[1] and G.pack_cards.cards[1].ability.set == "randmcrd")
	end,
        })
NFS.load(Palatro.path .. 'data/pal/Joker/ring_of_door.lua')()
NFS.load(Palatro.path .. 'data/pal/Joker/jokerkala.lua')()
NFS.load(Palatro.path .. 'data/pal/Enhance/double.lua')()
NFS.load(Palatro.path .. 'data/pal/booster/booster.lua')()
NFS.load(Palatro.path .. 'data/pal/Ranks/hranks.lua')()
NFS.load(Palatro.path .. 'data/pal/Joker/nom.lua')()
NFS.load(Palatro.path .. 'data/pal/Joker/sina.lua')()
NFS.load(Palatro.path .. 'data/pal/Joker/yildizlar.lua')()
NFS.load(Palatro.path .. 'data/pal/cons/countries.lua')()
local old_main_menu = Game.main_menu
Game.main_menu = function(change_context)
    -- color
    G.C.MY_PRIMARY   = {208/255, 255/255, 143/255, 1}   -- shir talebi :)
    G.C.MY_SECONDARY = {208/255, 255/255, 143/255, 1}
    G.C.TROOPS = {255/255, 68/255, 0/255, 1}

    local result = old_main_menu(change_context)

    -- background
    G.SPLASH_BACK:define_draw_steps({ {
        shader = 'splash',
        send = {
            { name = 'time',       ref_table = G.TIMERS, ref_value = 'REAL_SHADER' },
            { name = 'vort_speed', val = 0.4 },
            { name = 'colour_1',   ref_table = G.C,      ref_value = 'MY_PRIMARY' },
            { name = 'colour_2',   ref_table = G.C,      ref_value = 'MY_SECONDARY' },
        }
    } })

    -- main menu joker (base code from revo's vault)
local scale = 1.1 * 1.25

local newcard = Card(
    G.title_top.T.x,
    G.title_top.T.y,
    G.CARD_W * scale,
    G.CARD_H * scale,
    G.P_CARDS.empty,
    G.P_CENTERS.j_aao_parsa,
    { bypass_discovery_center = true }
)

G.title_top.T.w = G.title_top.T.w * scale
G.title_top.T.x = G.title_top.T.x - 0.8 

newcard:start_materialize({G.C.MY_PRIMARY, G.C.MY_SECONDARY}, true, 2.5)
G.title_top:emplace(newcard)

newcard.no_ui = true
    return result
end
SMODS.Rarity{
	key = "sum",
	loc_txt = {
		name = "Med-Rare"
	},
	badge_colour = HEX('eb9b34'),
	pools = {
		["Joker"] = true,  -- jokers with this rarity can apear in shop
    ["Joker"] = { rate = 0.7 }
	},
	get_weight = function(self, weight, object_type)
		if object_type == "Joker" then
			return weight   -- its % of apear in the shop
		end
		return weight
	end,
}
--icon of mod
SMODS.Atlas {
	key = "modicon",
	path = "modicon.png",
	px = 34,
	py = 34
}
Extension = SMODS.current_mod
Extension.compat = {
	cdrevo = (SMODS.Mods['RevosVault'] or {}).can_load,
}
-- copy-pasted directly from aikoshen

local origSoulRender = SMODS.DrawSteps.floating_sprite.func

SMODS.DrawStep:take_ownership('floating_sprite', {
    func = function(self, layer)
        if self.config and self.config.center_key == "j_aao_parsa" then
            if self.config.center.soul_pos and (self.config.center.discovered or self.bypass_discovery_center) then

                local t = G.TIMERS.REAL
                local scale_mod = 0.1
                local ymod = 0.15 * math.sin(t * 1.2)
                local xmod = 0.1 * math.sin(t * 0.9)

                local rotate_mod = 0.02 * math.cos(t * 0.7)

                self.children.floating_sprite:draw_shader('dissolve', 0, nil, nil, self.children.center, scale_mod, rotate_mod, xmod, ymod, nil, 0.6)
                self.children.floating_sprite:draw_shader('dissolve', nil, nil, nil, self.children.center, scale_mod, rotate_mod, xmod, ymod - 0.1)

                if self.edition then 
                    for _, v in pairs(G.P_CENTER_POOLS.Edition) do
                        if v.apply_to_float and self.edition[v.key:sub(3)] then
                            self.children.floating_sprite:draw_shader(v.shader, nil, nil, nil, self.children.center, scale_mod, rotate_mod, xmod, ymod - 0.1)
                        end
                    end
                end
            end
        else
            origSoulRender(self, layer)
        end
    end
})
SMODS.Atlas({
	key = "hikr",
	path = "hikr.png",
	px = 71,
	py = 95,
})
SMODS.Atlas({
	key = "blood_tsta",
	path = "dna.png",
	px = 71,
	py = 95,
})
SMODS.Atlas({
	key = "part__prin",
	path = "partner.png",
	px = 71,
	py = 95,
})
SMODS.Atlas({
	key = "peltzeratl",
	path = "seltzer.png",
	px = 71,
	py = 95,
})
SMODS.Atlas({
	key = "atlstencil",
	path = "stencil.png",
	px = 71,
	py = 95,
})
SMODS.Atlas({
	key = "atlegg",
	path = "egg.png",
	px = 71,
	py = 95,
})
SMODS.Atlas({
	key = "atloddp",
	path = "prime.png",
	px = 71,
	py = 95,
})
SMODS.Atlas({
	key = "atleven",
	path = "even.png",
	px = 71,
	py = 95,
})
SMODS.Atlas({
	key = "atlgold",
	path = "gold.png",
	px = 71,
	py = 95,
})
SMODS.Atlas({
	key = "atlspc",
	path = "space.png",
	px = 71,
	py = 95,
})
SMODS.Atlas({
	key = "atlparsa",
	path = "parsa.png",
	px = 71,
	py = 95,
})
-- ext addition --
--assert(SMODS.load_file("./data/fonts.lua"))()
-- revo extensions --
if Extension.compat.cdrevo then
NFS.load(Palatro.path .. 'data/ext/revo.lua')()
end
SMODS.Atlas {
    key = "bchipss",
    path = "blinds.png",
    px = 34,
    py = 34,
    atlas_table = 'ANIMATION_ATLAS',
    frames = 21,
}
SMODS.Blind{
  key = "end0lim",
  dollars = 5,
  mult = 2,
  boss_colour = HEX('000000'),
  atlas = 'bchipss',
  boss = { min = 1, max = 10 },
  pos   = { x = 0, y = 0 },
  debuff = {},
  loc_txt = {
    name = "End Of All Limits",
    text = { "Nothing special" }
  },

  set_blind = function(self)
      ease_background_colour{ new_colour = HEX('000000'), special_colour = HEX('696666') }
  end,
}
-- The 2m
SMODS.Blind {
    key = "two_m",
  dollars = 5,
  mult = 2,
  boss_colour = HEX('ff0000'),
  atlas = 'bchipss',
  boss = { min = 1, max = 10 },
  pos   = { x = 0, y = 1 },
    debuff = { h_size_le = 2 },
  loc_txt = {
    name = "2m",
    text = { "Only 2 card or less can score." }
  },

  set_blind = function(self)
      ease_background_colour{ new_colour = HEX('ff0000'), special_colour = HEX('ffffff') }
  end,
}
-- The 3 Suits
SMODS.Blind {
    key = "three_suits",
    dollars = 10,
    mult = 2,
    boss_colour = HEX("ff0000"),
    atlas = "bchipss",
    pos = { x = 0, y = 2 },
    boss = { showdown = true },

    loc_txt = {
        name = "30 KM",
        text = {
            "Debuffs everything if you have +30 cards,",
            "in your full deck."
        }
    },

      set_blind = function(self)
      ease_background_colour{ new_colour = HEX('ff0000'), special_colour = HEX('ffffff') }
  end,
    calculate = function(self, blind, context)
            if context.debuff_card then
            local deck_size = (G.deck and G.deck.cards) and #G.deck.cards or 52
            if deck_size > 30 then
                return{
                debuff = true
                }
            end
        end
    end
}
-- right left
SMODS.Blind {
    key = "rldi",
    dollars = 5,
    mult = 2,
    boss_colour = HEX("ff0000"),
    atlas = "bchipss",
    pos = { x = 0, y = 3 },
    boss = { min = 1 },

    loc_txt = {
        name = "Left and Right Unallowed",
        text = {
            "Debuffs rightmost and leftmost jokers",
        }
    },

      set_blind = function(self)
      ease_background_colour{ new_colour = HEX('ff0000'), special_colour = HEX('ffffff') }
    end,
calculate = function(self, blind, context)
        if not blind.disabled and G.jokers.cards[1] then
            if context.debuff_card and context.debuff_card == G.jokers.cards[1] then
                return { debuff = true }
            end
            if #G.jokers.cards > 1 and context.debuff_card and context.debuff_card == G.jokers.cards[#G.jokers.cards] then
                return { debuff = true }
            end
        end
    end,

    disable = function(self)
        for _, joker in ipairs(G.jokers.cards) do
            joker.ability.ends_lock_chosen = nil
        end
    end,

    defeat = function(self)
        for _, joker in ipairs(G.jokers.cards) do
            joker.ability.ends_lock_chosen = nil
        end
    end
}
-- no entry
SMODS.Blind {
    key = "neny",
  dollars = 5,
  mult = 2,
  boss_colour = HEX('ff0000'),
  atlas = 'bchipss',
  boss = { min = 1, max = 10 },
  pos   = { x = 0, y = 4 },
  loc_txt = {
    name = "No Entry",
    text = { "1 Hand and 1 Discard" }
  },
  set_blind = function(self)
      ease_background_colour{ new_colour = HEX('ff0000'), special_colour = HEX('ffffff') }
  end,
      calculate = function(self, blind, context)
        if not blind.disabled and context.setting_blind then
            blind.hands_sub = G.GAME.round_resets.hands - 1
            blind.discards_sub = G.GAME.round_resets.discards - 1
            ease_hands_played(-blind.hands_sub)
            ease_discard(-blind.discards_sub)
        end
    end,
    disable = function(self)
        if blind.hands_sub then
            ease_hands_played(blind.hands_sub)
            blind.hands_sub = nil
        end
        if blind.discards_sub then
            ease_discard(blind.discards_sub)
            blind.discards_sub = nil
        end
    end,
}

