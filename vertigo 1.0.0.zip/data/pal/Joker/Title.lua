
SMODS.Joker({
	key = "parsi",
	atlas = "palcehold",
	unlocked = true,
    cost = 10,
	discovered = true,
	no_collection = true,
	pos = {
		x = 2,
		y = 0,
	},
	in_pool = function(self)
		return false
	end,
})
